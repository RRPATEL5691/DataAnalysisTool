import {Component, View, NgZone, OnInit} from "angular2/core";
import {AgGridNg2} from 'ag-grid-ng2/main';
import {GridOptions} from "ag-grid/main";
import {DataService} from '../service/dataservice';
import {Observable} from 'rxjs/Observable';

@Component({
    selector: 'data-grid',
})

@View({
    directives: [AgGridNg2],
    templateUrl: './app/template/datagrid.html'
})

export class DataComponent implements OnInit {
    
    private gridOptions: GridOptions;
    private resultRows:any[] = [];
    private errorMessage:any = '';

    constructor(private zone:NgZone, private _dataService:DataService) {
        this.gridOptions = {
                rowData: [],
                columnDefs: [],
                enableColResize: true,
                enableSorting: true,
                enableFilter: true,
                showToolPanel: true
            };   
    }

    ngOnInit() {
        this.getRecords();
        //let timer = Observable.timer(1, 0);
        //timer.subscribe(() => this.getRecords())
    }

    getRecords(): void {
        this._dataService.getData()
            .subscribe(
                rowData => {
                    this.zone.run(() => {
                        this.resultRows = rowData;
                        this.getColumnHeaders(this.resultRows[0]) ;                        
                    });
                }, error => this.errorMessage = <any>error);             
   }
   
   getColumnHeaders(row){
        var columnHeader = [] ;    

        for (var key in row) {
            var keyName =  key.charAt(0).toUpperCase() + key.slice(1);
            columnHeader.push({headerName: keyName, field:key}) ;    
        }
        
        this.gridOptions.api.setColumnDefs(columnHeader);
        this.gridOptions.api.sizeColumnsToFit();
   }

}
