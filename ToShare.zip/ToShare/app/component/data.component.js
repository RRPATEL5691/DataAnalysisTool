System.register(["angular2/core", 'ag-grid-ng2/main', '../service/dataservice'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, main_1, dataservice_1;
    var DataComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (main_1_1) {
                main_1 = main_1_1;
            },
            function (dataservice_1_1) {
                dataservice_1 = dataservice_1_1;
            }],
        execute: function() {
            DataComponent = (function () {
                function DataComponent(zone, _dataService) {
                    this.zone = zone;
                    this._dataService = _dataService;
                    this.resultRows = [];
                    this.errorMessage = '';
                    this.gridOptions = {
                        rowData: [],
                        columnDefs: [],
                        enableColResize: true,
                        enableSorting: true,
                        enableFilter: true,
                        showToolPanel: true
                    };
                }
                DataComponent.prototype.ngOnInit = function () {
                    this.getRecords();
                    //let timer = Observable.timer(1, 0);
                    //timer.subscribe(() => this.getRecords())
                };
                DataComponent.prototype.getRecords = function () {
                    var _this = this;
                    this._dataService.getData()
                        .subscribe(function (rowData) {
                        _this.zone.run(function () {
                            _this.resultRows = rowData;
                            _this.getColumnHeaders(_this.resultRows[0]);
                        });
                    }, function (error) { return _this.errorMessage = error; });
                };
                DataComponent.prototype.getColumnHeaders = function (row) {
                    var columnHeader = [];
                    for (var key in row) {
                        var keyName = key.charAt(0).toUpperCase() + key.slice(1);
                        columnHeader.push({ headerName: keyName, field: key });
                    }
                    this.gridOptions.api.setColumnDefs(columnHeader);
                    this.gridOptions.api.sizeColumnsToFit();
                };
                DataComponent = __decorate([
                    core_1.Component({
                        selector: 'data-grid',
                    }),
                    core_1.View({
                        directives: [main_1.AgGridNg2],
                        templateUrl: './app/template/datagrid.html'
                    }), 
                    __metadata('design:paramtypes', [core_1.NgZone, dataservice_1.DataService])
                ], DataComponent);
                return DataComponent;
            }());
            exports_1("DataComponent", DataComponent);
        }
    }
});
//# sourceMappingURL=data.component.js.map