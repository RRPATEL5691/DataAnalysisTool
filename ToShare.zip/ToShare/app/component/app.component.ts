import {Component} from "angular2/core";
import {AgGridNg2} from 'ag-grid-ng2/main';
import {DataComponent} from './data.component';
import {DataService} from '../service/dataservice';

@Component({
    selector: 'my-grid',
    template: `<data-grid></data-grid>`,
    
    directives: <any>[DataComponent],
    providers: <any>[DataService]
})

export class AppComponent {
}